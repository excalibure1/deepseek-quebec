window.addEventListener('load', async () => {
  if (typeof window.ethereum !== 'undefined') {
    const web3 = new Web3(window.ethereum);
    await window.ethereum.enable();

    const contractABI = [{
      "inputs": [],
      "name": "ipfsHash",
      "outputs": [{"internalType": "string", "name": "", "type": "string"}],
      "stateMutability": "view",
      "type": "function"
    }];

    const contractAddress = "0x1234567890abcdef1234567890abcdef12345678";
    const contract = new web3.eth.Contract(contractABI, contractAddress);

    const hash = await contract.methods.ipfsHash().call();
    document.getElementById("root").innerHTML = `
      <h1>🌐 Tableau Web3 – Royaume du Québec</h1>
      <p>IPFS actuel : <code>${hash}</code></p>
    `;
  } else {
    document.getElementById("root").innerText = "🛑 MetaMask non détecté.";
  }
});
