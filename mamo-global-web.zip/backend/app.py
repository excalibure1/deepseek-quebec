from flask import Flask, request, jsonify
from flask_cors import CORS
from llama_cpp import Llama
import os
import time

app = Flask(__name__)
CORS(app)

MODEL_PATH = os.getenv("MODEL_PATH", "models/mamogpt_model.gguf")
llm = None
model_load_attempted = False

def load_model():
    global llm, model_load_attempted
    if model_load_attempted:
        return
    print("\n🌍 Initialisation du modèle MAMO...")
    if not os.path.exists(MODEL_PATH):
        print(f"❌ Modèle non trouvé : {MODEL_PATH}")
        return
    try:
        start = time.time()
        llm = Llama(model_path=MODEL_PATH, n_ctx=2048, n_threads=4)
        print(f"✅ Modèle chargé en {time.time() - start:.1f}s")
    except Exception as e:
        print(f"❌ Échec chargement : {str(e)}")
    model_load_attempted = True

@app.route("/")
def home():
    return "🌐 MAMO - API publique active"

@app.route("/api/mamo", methods=["POST"])
def mamo():
    load_model()
    if not llm:
        return jsonify({"error": "Modèle non disponible"}), 503
    data = request.get_json()
    prompt = data.get("prompt", "")
    if not prompt:
        return jsonify({"error": "Prompt vide"}), 400
    try:
        result = llm(prompt, max_tokens=200, temperature=0.7)
        return jsonify({
            "reply": result["choices"][0]["text"].strip(),
            "tokens": result.get("usage", {})
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    load_model()
    app.run(host="0.0.0.0", port=5000)
